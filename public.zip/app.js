const express=require('express')
const request=require('request')
const path=require('path')
const find=require('./find')
const bodyParser=require('body-parser')
const app=express()
app.set("view engine", "ejs"); 
app.use(bodyParser.urlencoded({extended:true}))

app.get("/",(req,res)=>{
    //res.sendFile(path.join(__dirname+'/home.html'))
    res.render("home",{active:"",cases:"",recovered:"",comment:""})
})
////////////////////////////////////////////////////////////////

app.get('/find',(req,res)=>{
     
    const url="https://data.covid19india.org/state_district_wise.json"
    request({url:url,json:true},(error,response)=>{
       

       const data=response.body
       res.send(data)
    //    const stateind=Object.keys(data)                              //Find the index of required state by iterating through the array
    //                                                                  //Our state is on the i index then get statedata[i]

    //    const statedata=Object.values(data)                                      //Array holding data of all states
    //    const AllCityData=Object.values(statedata[20])                           //All city data of that state
    //    const AllCityInd=Object.keys(AllCityData[0])      
    //    // res.send(AllCityInd)                                                                    
    //                                                                             //From the AllCityInd get index of ur city 
    //                                                                             //here its 0 
    //    const ReqCityData=Object.values(AllCityData[0]) 
    //     //res.send(ReqCityData[5])
    //     const details=Object.values(ReqCityData[5])  
    //     //res.send(details)      
    //     const active=details[1]
    //     const cases=details[2]
    //     const recovered=details[5] 
    //      res.send({
    //                   "Active":active,
    //                   "Cases":cases,
    //                   "Recovered":recovered
    //               })
    })
})

app.post("/",function(req,res){
    //res.send('Ayush')
    const url="https://data.covid19india.org/state_district_wise.json"
    request({url:url,json:true},(error,response)=>{
    const data=response.body
    //res.send(data)
    var userState=req.body.stateName;
    var userCity=req.body.cityName;
    var stateind=Object.keys(data)  
    var statedata=Object.values(data)
    //res.send(statedata)
    var ind1
    for(var i=0;i<stateind.length;i++)
    {
        var check=stateind[i]
        if(check===userState)
        {
            ind1=i;
            break;
        }
     
    }
    //console.log(ind1)
    //res.send('1')
    const AllCityData=Object.values(statedata[ind1])
    const AllCityInd=Object.keys(AllCityData[0])
    var ind2=-1
    for(i=0;i<AllCityInd.length;i++)
    {
        var checkk=AllCityInd[i]
        if(checkk===userCity)
        {
            ind2=i;
            break;
        }
        
    }
    const ReqCityData=Object.values(AllCityData[0]) 
    const details=Object.values(ReqCityData[ind2])  
    //res.send(details)
    var active=details[1]
    var cases=details[2]
    var recovered=details[5] 
    var cnt=cases-recovered
    // res.send({
    //                        "Active":active,
    //                        "Cases":cases,
    //                        "Recovered":recovered
    //                    })
    var rate=100-(((cases-recovered)/cases)*100)
    var comment="";
     if(active<=1000)
     {
         comment="Low risk,Visit after taking proper precautions."
     }else if(active>1000&&(active<=5000)){
         comment="Patient count is signicant,Vist if necessary."
     }else{
         comment="Patients are quite high do not visit now"
     }
    res.render("home",{active:"Active cases in "+userCity+" are "+active,cases:"Covid deaths tilldate in "+userCity+" are "+cnt,
    recovered:"Recovery rate in "+userCity+" is "+rate,comment:comment})
  })
})


/////////////////////////////////////////////////////////////////////////
app.listen(3000,()=>{
    console.log("server is up")
})